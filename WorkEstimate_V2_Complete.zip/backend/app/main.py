from fastapi import FastAPI, UploadFile, File, HTTPException
from pydantic import BaseModel
import os, uuid

app = FastAPI(title="WorkEstimate API V2")

class EstimateRequest(BaseModel):
    project_id: str = None
    items: list = []

@app.get("/health")
def health():
    return {"status":"ok"}

@app.post("/auth/login")
def login(data: dict):
    return {"token":"fake-jwt-token-v2"}

@app.post("/estimate/calc")
def calc_estimate(req: EstimateRequest):
    # TODO: implement pricing engine, include menuiseries and immovables
    return {"estimate":{"total": 2500.0, "breakdown":[{"item":"peinture","cost":800}] } }

@app.post("/ai/detect")
async def ai_detect(file: UploadFile = File(...)):
    ai_url = os.environ.get("AI_SERVICE_URL", "http://ai:8001") + "/detect"
    files = {"file": (file.filename, await file.read(), file.content_type)}
    import requests
    try:
        r = requests.post(ai_url, files=files, timeout=10)
        return r.json()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/plans/2d/generate")
async def generate_plan_pdf(project_id: str = None):
    filename = f"/tmp/plan_{project_id or str(uuid.uuid4())}.pdf"
    with open(filename, "wb") as f:
        f.write(b"%PDF-1.4\n%PDF-PLACEHOLDER")
    return {"url":"file://" + filename}

@app.post("/vision/3d/generate")
async def generate_vision3d(project_id: str = None):
    filename = f"/tmp/vision3d_{project_id or str(uuid.uuid4())}.obj"
    with open(filename, "wb") as f:
        f.write(b"# OBJ-PLACEHOLDER")
    return {"url":"file://" + filename}

@app.post("/export/pay")
def export_pay(user_id: str, method: str = "immediate"):
    # method: 'credit' or 'immediate'
    # Placeholder: validate payment with provider
    return {"status":"ok","message":"Export unlocked for user "+user_id}
