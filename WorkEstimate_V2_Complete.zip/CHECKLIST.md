# Quick Checklist - WorkEstimate V2 Complete

1. unzip the repo and `cd` to the folder
2. copy `.env.example` to `.env` and edit values if needed
3. run `docker-compose up --build` (requires Docker & Docker Compose)
4. open:
   - Backend docs: http://localhost:8000/docs
   - AI service docs: http://localhost:8001/docs
   - Web: http://localhost:3000
5. To test features:
   - POST /estimate/calc to backend
   - POST /plans/2d/generate to backend
   - POST /vision/3d/generate to backend
   - POST /export/pay to simulate export purchase
6. Push to GitHub and configure secrets: PAYMENT_PROVIDER_API_KEY, NPM_TOKEN, PYPI_TOKEN, DOCKERHUB_TOKEN, VERCEL_TOKEN
