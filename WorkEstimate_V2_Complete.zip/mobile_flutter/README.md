# Work Estimate Mobile (Flutter)

This folder is a placeholder for the Flutter app.
Implement screens: Home, Estimate flow (AR), Results (Generate 2D/3D), Pro Dashboard.
Logo is configurable in app settings (/assets/logo.png).
