export default function Devis(){return (<div style={{padding:40}}>
  <h1>Devis détaillé</h1>
  <p>Contient Plans 2D rénové & Vision 3D rénovée</p>
</div>)}