export default function Home(){return (<div style={{fontFamily:'Arial',padding:40}}>
  <img src="/assets/logo.png" alt="logo" style={{width:120}} />
  <h1>Work Estimate V2</h1>
  <p>Estimation rapide, Plans 2D (PDF) et Vision 3D 360°</p>
  <a href="/estimate">Nouvelle estimation</a>
</div>)}