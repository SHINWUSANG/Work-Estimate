export default function Estimate(){return (<div style={{padding:40}}>
  <h1>Nouvelle estimation</h1>
  <p>Formulaire simplifié (surface, type, matériaux)</p>
  <button>Générer Plans 2D (PDF)</button>
  <button>Générer Vision 3D 360°</button>
</div>)}