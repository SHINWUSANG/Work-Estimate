# Wireframes & Maquettes V2

- Logo : configurable / remplaçable dans l'app
- 2.2 Création d'estimation : résultats -> Plans 2D cotés (PDF) [Générer], Vision 3D 360° [Générer]
- 2.3 Écran devis détaillé : inclut Plans 2D rénové et Vision 3D rénovée
