# Cahier des charges V2 (extraits)

## 1.4.A Estimation automatique
- Tableau récapitulatif des éléments de menuiseries pièce par pièce
- Liste des éléments inamovibles : sanitaires, cuisine, douche

## 1.4.B Mesure automatique via la caméra
- Détection des portes, fenêtres, éléments inamovibles
- Détection des prises et luminaires
- Détection des câbles et conduits apparents

## 1.4.D Gestion des projets
- Plans 2D cotés en centimètres, exportable en PDF
- Vision 3D 360° exportable
- Simulateur 2D/3D
- Export payant (crédit ou paiement immédiat de 2€)
