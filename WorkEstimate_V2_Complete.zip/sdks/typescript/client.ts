export async function calcEstimate(apiUrl, payload, token){
  const res = await fetch(apiUrl + '/estimate/calc', {method:'POST', headers:{'Content-Type':'application/json', ...(token?{'Authorization':'Bearer '+token}:{})}, body:JSON.stringify(payload)});
  return res.json();
}
