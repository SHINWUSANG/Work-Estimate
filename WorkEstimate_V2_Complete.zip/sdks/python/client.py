import requests
class Client:
    def __init__(self, api_url, token=None):
        self.api_url=api_url
        self.token=token
    def calc_estimate(self, payload):
        return requests.post(self.api_url+'/estimate/calc', json=payload, headers={'Authorization':'Bearer '+(self.token or '')}).json()
